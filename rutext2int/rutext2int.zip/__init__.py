from rutext2int.main import Text2IntRU
